package com.example.fypversion1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginSlave extends AppCompatActivity {

    private Button loginButton;
    private EditText emailId, password;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_slave);

        mFirebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.slave_email);
        password = findViewById(R.id.slave_password);
        loginButton = findViewById(R.id.slave_signin);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if( mFirebaseUser != null ){
                    Toast.makeText(LoginSlave.this,"You are logged in",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginSlave.this, SlaveMain.class);
                    startActivity(i);
                }
                else{
                    Toast.makeText(LoginSlave.this,"Please Login",Toast.LENGTH_SHORT).show();
                }
            }
        };

        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openSlaveMain();
            }
        });
    }

    public void openSlaveMain(){
        String email = emailId.getText().toString();
        String pwd = password.getText().toString();

        if(email.isEmpty() && pwd.isEmpty()){
            Toast.makeText(LoginSlave.this,"Fields Are Empty!",Toast.LENGTH_SHORT).show();
        }

        else if(email.isEmpty()){
            emailId.setError("Please enter email id");
            emailId.requestFocus();
        }
        else if(pwd.isEmpty()){
            password.setError("Please enter your password");
            password.requestFocus();
        }

        else if(!(email.isEmpty() && pwd.isEmpty())){
            mFirebaseAuth.signInWithEmailAndPassword(email, pwd).addOnCompleteListener(LoginSlave.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(!task.isSuccessful()){
                        Toast.makeText(LoginSlave.this,"Login Error, Please Login Again",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Intent intToHome = new Intent(LoginSlave.this,SlaveMain.class);
                        startActivity(intToHome);
                    }
                }
            });
        }
        else{
            Toast.makeText(LoginSlave.this,"Error Occurred!",Toast.LENGTH_SHORT).show();

        }

    }
}
