package com.example.fypversion1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import android.Manifest;

import android.content.Intent;
import android.content.pm.PackageManager;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


public class SlaveMain extends AppCompatActivity {

    private ImageButton IntrusionButton;
    private ImageButton FireButton;
    private ImageButton SmokeButton;
    private Button logout;
    private static final int CAMERA_PERM_CODE = 101;

    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slave_main);

        storageReference = FirebaseStorage.getInstance().getReference();
        IntrusionButton = (ImageButton) findViewById(R.id.IntrusionButton);
        IntrusionButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                askCameraPermission();
            }
        });

        FireButton = (ImageButton) findViewById(R.id.FireButton);
        FireButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                askCameraPermission();
            }
        });

        SmokeButton = (ImageButton) findViewById(R.id.SmokeButton);
        SmokeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                askCameraPermission();
            }
        });

        logout = (Button) findViewById(R.id.Slave_LogOut);
        logout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                LogOut();
            }
        });

    }

    public void openCamera(){
        Intent intent = new Intent(this, CameraActivity.class);
        startActivity(intent);
    }

    public void askCameraPermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CAMERA}, CAMERA_PERM_CODE );
        }
        else{
            openCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == CAMERA_PERM_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                openCamera();
            }
            else{
                Toast.makeText(this, "Camera Permission is Required to access camera!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void LogOut(){
        FirebaseAuth.getInstance().signOut();
        Intent intent1 = new Intent(this, Login.class);
        startActivity(intent1);
    }

}
