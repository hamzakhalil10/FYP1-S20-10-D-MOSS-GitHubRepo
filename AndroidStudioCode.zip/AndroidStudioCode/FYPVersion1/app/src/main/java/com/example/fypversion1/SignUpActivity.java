package com.example.fypversion1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {
    private EditText emailId, password, confrimPass;
    private Button btnSignUp;
    FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_1);

        mFirebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.reg_email);
        password = findViewById(R.id.reg_password);
        btnSignUp = findViewById(R.id.reg_button);
        confrimPass = findViewById(R.id.confrm_password);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openMasterMain();
            }
        });

    }
    public void openMasterMain(){
        String email = emailId.getText().toString();
        String pwd = password.getText().toString();
        String cpwd = password.getText().toString();

        if(email.isEmpty() && pwd.isEmpty() && cpwd.isEmpty()){
            Toast.makeText(SignUpActivity.this,"Fields Are Empty!",Toast.LENGTH_SHORT).show();
        }

        else if(email.isEmpty()){
            emailId.setError("Please enter email id");
            emailId.requestFocus();
        }
        else  if(pwd.isEmpty()){
            password.setError("Please enter your password");
            password.requestFocus();
        }
        else  if(cpwd.isEmpty()){
            password.setError("Please confirm your password");
            password.requestFocus();
        }


        else  if(!(email.isEmpty() && pwd.isEmpty() && cpwd.isEmpty())){
            mFirebaseAuth.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(!task.isSuccessful()){
                        Toast.makeText(SignUpActivity.this,"SignUp Unsuccessful, Please Try Again",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        startActivity(new Intent(SignUpActivity.this,MasterMainActivity.class));
                    }
                }
            });
        }
        else{
            Toast.makeText(SignUpActivity.this,"Error Occurred!",Toast.LENGTH_SHORT).show();

        }
    }
}
