package com.example.fypversion1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.res.Configuration;

import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;

import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.IOException;


public class CameraActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    private String counter ="1";
    private Button btnCapture;
    private SurfaceView surfaceView;
    private Camera camera;
    private SurfaceHolder surfaceHolder;
    private Camera.PictureCallback pictureCallback;
    private Boolean checkAlert = false;
    StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        surfaceView= findViewById(R.id.surfaceView);
        btnCapture = findViewById(R.id.CaptureButton);

        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        storageReference = FirebaseStorage.getInstance().getReference();


        btnCapture.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                camera.takePicture(null,null,pictureCallback);
            }
        });

        pictureCallback = new Camera.PictureCallback(){
            @Override
            public void onPictureTaken(byte[] bytes, Camera camera){
                /*Bitmap bmp = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                Bitmap cbmp = Bitmap.createBitmap(bmp,0,0,bmp.getWidth(),bmp.getHeight(),null,true);
                String pathFileName = currentDateFormat();
                storePhotoToStorage(cbmp,pathFileName);*/
                Toast.makeText(getApplicationContext(), "Done!",Toast.LENGTH_LONG).show();
                checkAlert=false;
                //////////////
                final StorageReference image = storageReference.child("pictures/alert"+counter +".jpg");
                UploadTask uploadTask = image.putBytes(bytes);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        Toast.makeText(CameraActivity.this, "Upload Failed.", Toast.LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        // ...
                        image.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                Toast.makeText(CameraActivity.this, "Upload Successful.", Toast.LENGTH_SHORT).show();
                            }
                        });
                        int i = Integer.parseInt(counter);
                        i++;
                        counter = Integer.toString(i);
                        checkAlert=true;
                    }
                });

                CameraActivity.this.camera.startPreview();
            }
        };
    }

    /*private void storePhotoToStorage(Bitmap cbmp, String pathFileName){
        File outputFile = new File(Environment.getExternalStorageDirectory(),Environment.DIRECTORY_DCIM+"photo"+pathFileName+".jpg");

        try{
            FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
            cbmp.compress(Bitmap.CompressFormat.JPEG, 100,fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    private String currentDateFormat(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HH_mm_ss");
        String currentTime = dateFormat.format(new Date());
        return currentTime;
    }*/
    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder){
        try{
            camera = Camera.open();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        Camera.Parameters parameters;
        parameters = camera.getParameters();

        //orientation
        if(this.getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE){
            parameters.set("orientation","portrait");
            camera.setDisplayOrientation(90);
            parameters.setRotation(90);
        }
        else{
            parameters.set("orientation","landscape");
            camera.setDisplayOrientation(0);
            parameters.setRotation(0);
        }


        camera.setParameters(parameters);

        try{
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2){

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder){
        camera.stopPreview();
        camera.release();
        camera = null;
    }

    public String getCounter(){
        return counter;
    }

    public Boolean getCheckAlert(){
        return checkAlert;
    }

}
