package com.example.fypversion1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;


public class LoginMaster extends AppCompatActivity {
    private Button regButton;
    private Button signin;
    private EditText emailId, password;
    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_master);

        mFirebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.mast_email);
        password = findViewById(R.id.mast_password);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if( mFirebaseUser != null ){
                    Toast.makeText(LoginMaster.this,"You are logged in",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginMaster.this, MasterMainActivity.class);
                    startActivity(i);
                }
                else{
                    Toast.makeText(LoginMaster.this,"Please Login",Toast.LENGTH_SHORT).show();
                }
            }
        };

        regButton = (Button) findViewById(R.id.mast_signup);
        regButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openSignUp();
            }
        });

        signin = (Button) findViewById(R.id.mast_signin);
        signin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                openSignIn();
            }
        });



    }
    public void openSignUp(){
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }

    public void openSignIn(){
        String email = emailId.getText().toString();
        String pwd = password.getText().toString();

        if(email.isEmpty() && pwd.isEmpty()){
            Toast.makeText(LoginMaster.this,"Please fill the fields!",Toast.LENGTH_SHORT).show();
        }

        else if(email.isEmpty()){
            emailId.setError("Please enter email id");
            emailId.requestFocus();
        }
        else if(pwd.isEmpty()){
            password.setError("Please enter your password");
            password.requestFocus();
        }

        else if(!(email.isEmpty() && pwd.isEmpty())){
            mFirebaseAuth.signInWithEmailAndPassword(email, pwd).addOnCompleteListener(LoginMaster.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(!task.isSuccessful()){
                        Toast.makeText(LoginMaster.this,"Login Error, Please Login Again",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Intent intToHome = new Intent(LoginMaster.this,MasterMainActivity.class);
                        startActivity(intToHome);
                    }
                }
            });
        }
        else{
            Toast.makeText(LoginMaster.this,"Error Occurred!",Toast.LENGTH_SHORT).show();

        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

}
